import express from "express";
import morgan from "morgan";
import routes from "./src/routes.js";

const app = express();

app.use(morgan("dev"));
app.use(express.json());
app.use(routes);

app.listen(8000, () => {
    console.log("O servidor está rodando na porta 8000");
});