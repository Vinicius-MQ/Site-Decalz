import express from "express";

const routes = express.Router();

let database = [
    {1: {Name: "Goku", Type: "Anime"}},
    {2: {Name: "Naruto", Type: "Anime"}}
];

routes.get("/", (req, res) => res.json(database));

routes.post("/add", (req, res) => {
    const body = req.body;

    if (!body) return res.status(400).end();

    database.push(body);

    return res.json(body);
});

routes.delete("/:id", (req, res) => {
    const id = req.params.id;

    const newDatabase = database.filter((item) => {
        if (!item[id]) return item;
    });

    database = newDatabase;

    return res.send(newDatabase);
});

export default routes;